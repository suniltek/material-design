-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 28, 2019 at 07:44 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmr_call`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `description`, `status`) VALUES
(1, 'Life Sciences', 'If your Apache server has mod_rewrite enabled, you can easily remove this file by using a .htaccess file with some simple rules. Here is an example of such a file, using the “negative” method in which everything is redirected except the specified items:', 'Active'),
(2, 'Consumer Goods', 'If your Apache server has mod_rewrite enabled, you can easily remove this file by using a .htaccess file with some simple rules. Here is an example of such a file, using the “negative” method in which everything is redirected except the specified items:', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_id` int(11) NOT NULL,
  `question` varchar(1000) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `report_id`, `question`, `created_at`, `updated_at`) VALUES
(1, 7, 'how much fuel import?', '2019-01-27 12:11:09', '2019-01-27 17:41:09'),
(2, 7, 'how much fuel export?', '2019-01-27 12:11:09', '2019-01-27 17:41:09'),
(3, 8, 'lorem', '2019-01-27 12:33:17', '2019-01-27 18:03:17'),
(4, 9, 'lorem', '2019-01-27 12:33:57', '2019-01-27 18:03:57'),
(5, 10, 'lorem', '2019-01-27 12:35:05', '2019-01-27 18:05:05'),
(6, 11, 'lorem', '2019-01-27 12:44:54', '2019-01-27 18:14:54'),
(7, 12, 'lorem', '2019-01-27 12:49:17', '2019-01-27 18:19:17'),
(8, 13, 'name', '2019-01-28 00:03:01', '2019-01-28 05:33:01'),
(9, 13, 'surname', '2019-01-28 00:03:01', '2019-01-28 05:33:01'),
(10, 13, 'job', '2019-01-28 00:03:01', '2019-01-28 05:33:01'),
(11, 14, 'name', '2019-01-28 00:08:04', '2019-01-28 05:38:04'),
(12, 14, 'surname', '2019-01-28 00:08:04', '2019-01-28 05:38:04'),
(13, 14, 'job', '2019-01-28 00:08:04', '2019-01-28 05:38:04');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

DROP TABLE IF EXISTS `reports`;
CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `manager_id` int(11) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `no_of_questions` int(11) NOT NULL,
  `no_of_respondent` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `title`, `category_id`, `subcategory_id`, `manager_id`, `owner_id`, `no_of_questions`, `no_of_respondent`, `created_at`, `updated_at`) VALUES
(1, 'shailesh', 1, 1, 2, 1, 2, 5, NULL, '2019-01-27 15:30:35'),
(2, 'shailesh', 1, 1, 2, 1, 2, 5, NULL, '2019-01-27 15:31:50'),
(3, 'shailesh', 2, 4, 1, 1, 0, 3, NULL, '2019-01-27 15:32:15'),
(4, 'shailesh', 2, 3, 2, 1, 1, 12, NULL, '2019-01-27 15:33:48'),
(5, 'shailesh', 1, 2, 2, 1, 2, 5, NULL, '2019-01-27 17:19:59'),
(6, 'Fuel market', 1, 2, 1, 1, 2, 10, '2019-01-27 12:10:22', '2019-01-27 17:40:22'),
(7, 'Fuel market', 1, 2, 1, 1, 2, 10, '2019-01-27 12:11:09', '2019-01-27 17:41:09'),
(8, 'shailesh', 2, 3, 1, 1, 1, 2, '2019-01-27 12:33:17', '2019-01-27 18:03:17'),
(9, 'shailesh', 2, 3, 1, 1, 1, 2, '2019-01-27 12:33:57', '2019-01-27 18:03:57'),
(10, 'shailesh', 2, 3, 1, 1, 1, 2, '2019-01-27 12:35:05', '2019-01-27 18:05:05'),
(11, 'shailesh', 2, 3, 1, 1, 1, 2, '2019-01-27 12:44:54', '2019-01-27 18:14:54'),
(12, 'shailesh', 2, 3, 1, 1, 1, 2, '2019-01-27 12:49:17', '2019-01-27 18:19:17'),
(13, 'shailesh', 1, 1, 1, 1, 3, 5, '2019-01-28 00:03:01', '2019-01-28 05:33:01'),
(14, 'shailesh', 1, 1, 1, 1, 3, 5, '2019-01-28 00:08:04', '2019-01-28 05:38:04');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

DROP TABLE IF EXISTS `subcategories`;
CREATE TABLE IF NOT EXISTS `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Active','Inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `title`, `description`, `status`) VALUES
(1, 1, 'Pharmaceuticals', 'If your Apache server has mod_rewrite enabled, you can easily remove this file by using a .htaccess file with some simple rules. Here is an example of such a file, using the “negative” method in which everything is redirected except the specified items:', 'Active'),
(2, 1, 'Healthcare', 'If your Apache server has mod_rewrite enabled, you can easily remove this file by using a .htaccess file with some simple rules. Here is an example of such a file, using the “negative” method in which everything is redirected except the specified items:', 'Active'),
(3, 2, 'Consumer Electronics', 'If your Apache server has mod_rewrite enabled, you can easily remove this file by using a .htaccess file with some simple rules. Here is an example of such a file, using the “negative” method in which everything is redirected except the specified items:', 'Active'),
(4, 2, 'Home Products', 'If your Apache server has mod_rewrite enabled, you can easily remove this file by using a .htaccess file with some simple rules. Here is an example of such a file, using the “negative” method in which everything is redirected except the specified items:', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `job_role` enum('Manager','Owner') NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `job_role`, `email`) VALUES
(1, 'Shailesh Dhokare', 'Manager', 'sd@test.com'),
(2, 'Ravi Mane', 'Manager', 'rm@test.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
