<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Model{
   public function getCategories()
   {
      $this->load->database();
      $query = $this->db->select('id, title')->where('status', 'Active')->get('categories');
      $cats = $query->result();
      return $cats;
   }

   public function getSubCategories($query)
   {
      $this->load->database();
      $query = $this->db->select('id, title')->where('category_id', $query)->get('subcategories');
      $subcats = $query->result();
      return $subcats;
   }

   public function getManagers()
   {
      $this->load->database();
      $query = $this->db->select('id, name')->where('job_role', 'Manager')->get('users');
      $managers = $query->result();
      return $managers;
   }

   public function createReport(array $data){
      $this->load->database();
      $q = $this->db->insert('reports',$data);
      if ($this->db->affected_rows() > 0) {
        $insert_id = $this->db->insert_id();
        return  $insert_id; 
      } 
   }

   public function saveQuestions(array $data){
      $this->load->database();
      $q = $this->db->insert('questions',$data);
      if ($this->db->affected_rows() > 0) {
        $insert_id = $this->db->insert_id();
        return  $insert_id; 
      } 
   }

   public function getPrimaryList(){
      $this->load->database();

      // $this->db->select('reports.*, users.name, categories.title, subcategories.title');
      // $this->db->from('reports r'); 
      // $this->db->join('users u', 'r.manager_id = u.id', 'left');
      // $this->db->join('categories c', 'c.id=r.category_id', 'left');
      // $this->db->join('subcategories s', 's.id=r.subcategory_id', 'left');
      // $this->db->order_by('r.created_at','desc');         
      // $query = $this->db->get();

      $query = $this->db->query("SELECT reports.*, users.name, categories.title AS category, subcategories.title AS subcategory FROM reports LEFT JOIN users ON users.id = reports.manager_id LEFT JOIN categories ON categories.id = reports.category_id LEFT JOIN subcategories ON subcategories.id = reports.subcategory_id ORDER BY reports.id DESC");

      if($query->num_rows() != 0)
      {
          return $query->result();
      }
      else
      {
          return false;
      }
     
   }

   public function showReport($id){
    $this->load->database();
    $query = $this->db->query("SELECT reports.*, users.name, categories.title AS category, subcategories.title AS subcategory FROM reports LEFT JOIN users ON users.id = reports.manager_id LEFT JOIN categories ON categories.id = reports.category_id LEFT JOIN subcategories ON subcategories.id = reports.subcategory_id WHERE reports.id = '$id'");

    if($query->num_rows() != 0)
    {
        return $query->result();
    }
    else
    {
        return false;
    }

   }

   public function getQuestions($id){
    $this->load->database();
    $query = $this->db->where('report_id', $id)->get('questions');
    if($query->num_rows() != 0)
    {
        return $query->result();
    }
    else
    {
        return false;
    }

   }


}