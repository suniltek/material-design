<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url('assets/images/favicon.png'); ?>">
    <title>Primary Calling</title>
    <!-- Custom CSS -->
    <link href="<?= base_url('assets/css/style.min.css'); ?>" rel="stylesheet">
    <link href="<?= base_url('assets/css/custom.css'); ?>" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin5">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin5">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)">
                        <i class="ti-menu ti-close"></i>
                    </a>
                    <!-- ============================================================== -->
                    <!-- Logo -->
                    <!-- ============================================================== -->
                    <a class="navbar-brand" href="index.html">
                        <!-- Logo icon -->
                        <b class="logo-icon p-l-10">
                            <img src="../assets/images/logo-icon.png" alt="homepage" class="light-logo" />
                        </b>
                        <b class="logo-icon">
                            <!-- Dark Logo icon -->
                            Primary Calling
                        </b>
                        <!--End Logo icon -->
                    </a>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-left mr-auto">
                        <li class="nav-item d-none d-md-block"><a class="nav-link sidebartoggler waves-effect waves-light" href="javascript:void(0)" data-sidebartype="mini-sidebar"><i class="mdi mdi-menu font-24"></i></a></li>
                        <!-- Search -->
                        <!-- ============================================================== -->
                        <li class="nav-item search-box"> <a class="nav-link waves-effect waves-dark" href="javascript:void(0)"><i class="ti-search"></i></a>
                            <form class="app-search position-absolute">
                                <input type="text" class="form-control" placeholder="Search &amp; enter"> <a class="srh-btn"><i class="ti-close"></i></a>
                            </form>
                        </li>
                    </ul>
                    <!-- ============================================================== -->
                    <!-- Right side toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav float-right">
                        <!-- ============================================================== -->
                        <!-- Messages -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle waves-effect waves-dark" href="" id="2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="font-24 mdi mdi-comment-processing"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right mailbox animated bounceInDown" aria-labelledby="2">
                                <ul class="list-style-none">
                                    <li>
                                        <div class="">
                                             <!-- Message -->
                                            <a href="javascript:void(0)" class="link border-top">
                                                <div class="d-flex no-block align-items-center p-10">
                                                    <span class="btn btn-success btn-circle"><i class="ti-calendar"></i></span>
                                                    <div class="m-l-10">
                                                        <h5 class="m-b-0">Event today</h5> 
                                                        <span class="mail-desc">Just a reminder that event</span> 
                                                    </div>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="javascript:void(0)" class="link border-top">
                                                <div class="d-flex no-block align-items-center p-10">
                                                    <span class="btn btn-info btn-circle"><i class="ti-settings"></i></span>
                                                    <div class="m-l-10">
                                                        <h5 class="m-b-0">Settings</h5> 
                                                        <span class="mail-desc">You can customize this template</span> 
                                                    </div>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="javascript:void(0)" class="link border-top">
                                                <div class="d-flex no-block align-items-center p-10">
                                                    <span class="btn btn-primary btn-circle"><i class="ti-user"></i></span>
                                                    <div class="m-l-10">
                                                        <h5 class="m-b-0">Pavan kumar</h5> 
                                                        <span class="mail-desc">Just see the my admin!</span> 
                                                    </div>
                                                </div>
                                            </a>
                                            <!-- Message -->
                                            <a href="javascript:void(0)" class="link border-top">
                                                <div class="d-flex no-block align-items-center p-10">
                                                    <span class="btn btn-danger btn-circle"><i class="fa fa-link"></i></span>
                                                    <div class="m-l-10">
                                                        <h5 class="m-b-0">Luanch Admin</h5> 
                                                        <span class="mail-desc">Just see the my new admin!</span> 
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- End Messages -->
                        <!-- ============================================================== -->

                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark pro-pic" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="../assets/images/users/1.jpg" alt="user" class="rounded-circle" width="31"></a>
                            <div class="dropdown-menu dropdown-menu-right user-dd animated">
                                <a class="dropdown-item" href="javascript:void(0)"><i class="ti-user m-r-5 m-l-5"></i> My Profile</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="javascript:void(0)"><i class="fa fa-power-off m-r-5 m-l-5"></i> Logout</a>
                                <div class="dropdown-divider"></div>
                                <div class="p-l-30 p-10"><a href="javascript:void(0)" class="btn btn-sm btn-success btn-rounded">View Profile</a></div>
                            </div>
                        </li>
                        <!-- ============================================================== -->
                        <!-- User profile and search -->
                        <!-- ============================================================== -->
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="primary-details.html" aria-expanded="false">
                                <i class="mdi mdi-view-module"></i><span class="hide-menu">Primary Details</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="primary-list.html" aria-expanded="false">
                                <i class="mdi mdi-view-module"></i><span class="hide-menu">Primary List</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="company-list.html" aria-expanded="false">
                                <i class="mdi mdi-format-list-bulleted"></i><span class="hide-menu">Company List</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                                <i class="mdi mdi-gamepad"></i><span class="hide-menu">All Category </span>
                            </a>
                            <ul aria-expanded="false" class="collapse first-level">
                                <li class="sidebar-item">
                                    <a href="form-basic.html" class="sidebar-link">
                                        <i class="mdi mdi-cisco-webex"></i><span class="hide-menu"> Life Science </span>
                                    </a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="form-basic.html" class="sidebar-link">
                                        <i class="mdi mdi-cisco-webex"></i><span class="hide-menu"> Consumer Goods </span>
                                    </a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="form-basic.html" class="sidebar-link">
                                        <i class="mdi mdi-cisco-webex"></i><span class="hide-menu"> Materials and Chemicals </span>
                                    </a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="form-basic.html" class="sidebar-link">
                                        <i class="mdi mdi-cisco-webex"></i><span class="hide-menu"> Food and Beverages </span>
                                    </a>
                                </li>
                                <li class="sidebar-item">
                                    <a href="form-basic.html" class="sidebar-link">
                                        <i class="mdi mdi-cisco-webex"></i><span class="hide-menu"> Energy and Power </span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Primary Details</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Primary List</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h1 class="pd-title"><?php echo $report[0]->title ?></h1>
                                <p style="font-size:16px;">
                                    by Application (Hypogammaglobulinemia, Chronic Inflammatory Demyelinating Polyneuropathy, 
                                    Immunodeficiency Disease, Myasthenia Gravis, Multifocal Motor Neuropathy, Idiopathic Thrombocytopenic
                                    Purpura, Inflammatory Myopathies, Specific Antibody Deficiency, Guillain - Barre Syndrome, and Others)
                                    and Type (IgG, IgA, IgM, IgE, and IgD: Global Opportunity Analysis and Industry Forecast, 2016 - 2022
                                </p>
                                <i class="mdi mdi-star pd-star-fill"></i>
                                <i class="mdi mdi-star pd-star-fill"></i>
                                <i class="mdi mdi-star pd-star-fill"></i>
                                <i class="mdi mdi-star pd-star-fill"></i>
                                <i class="mdi mdi-star-outline pd-star-outline"></i>

                                <div class="clearfix w-100">&nbsp;</div>

                                <div class="pd-info">
                                    <div><a href=""><?php echo $report[0]->category ?>/<?php echo $report[0]->subcategory ?></a></div>        
                                    <div><span>LI_16325</span></div>
                                    <div><span>Dec 2018</span></div>
                                    <div><span>Author's: Online Sumant and Tenzin Kunsel</span></div>
                                    <div><span>Tables: 37</span></div>
                                    <div><span>Charts: 29</span></div>
                                </div>
                            </div>
                        </div>       
                            
                        <div class="clearfix w-100"></div>

                        <div class="card">
                            <div class="card-header pd-tab-header">
                                <div class="pd-tab-info">
                                    <div>
                                        <h3>RESEARCH ANALYST: <span>Sandesh Tambe</span></h3>
                                    </div>  
                                    <div>
                                        <h3>RESEARCH MANAGER: <span>Snehal Chavan</span></h3>
                                    </div>  
                                    <div>
                                        <h3>DATE: <span>10-12-2018</span></h3>
                                    </div>
                                </div>   
                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link pd-nav-links active" data-toggle="tab" href="#pri-01" role="tab">
                                            <span class="hidden-sm-up"></span> <span class="hidden-xs-down"><strong>Primary 01</strong></span>
                                        </a>
                                    </li>
                                    <?php $pmr = 1; ?>
                                    <?php foreach($questions as $question): ?>
                                        <li class="nav-item"> 
                                            <a class="nav-link pd-nav-links" data-toggle="tab" href="#pri-<?php echo $question->id;?>" role="tab">
                                                <span class="hidden-sm-up"></span> <span class="hidden-xs-down"><strong>Primary <?php echo ++$pmr ?>  </strong></span>
                                            </a>
                                        </li>
                                    <?php endforeach ?>
                                    <!-- <li class="nav-item"> 
                                        <a class="nav-link pd-nav-links" data-toggle="tab" href="#pri-02" role="tab">
                                            <span class="hidden-sm-up"></span> <span class="hidden-xs-down"><strong>Primary 02 </strong></span>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link pd-nav-links" data-toggle="tab" href="#pri-03" role="tab">
                                            <span class="hidden-sm-up"></span> <span class="hidden-xs-down"><strong>Primary 03 </strong></span>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link pd-nav-links" data-toggle="tab" href="#pri-04" role="tab">
                                            <span class="hidden-sm-up"></span> <span class="hidden-xs-down"><strong>Primary 04 </strong></span>
                                        </a>
                                    </li> -->
                                </ul>
                            </div>
                            <!-- Tab panes -->
                            <div class="tab-content tabcontent-border">
                                <div class="tab-pane active" id="pri-01" role="tabpanel">
                                    <div class="p-20">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <h4 class="pd-tabcontent-title">QUATION : What happens during the primary immune response?</h4>
                                                <p class="pd-tabcontent-desc">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta odit, aut placeat unde ex molestias sed,
                                                    laborum cupiditate est facilis autem voluptas fuga, vel quibusdam quo similique suscipit aliquid?
                                                    Exercitationem.oluta odit, aut placeat unde ex molestias sed, laborum cupiditate est 
                                                    facilis autem voluptas fuga, vel quibusdam quo similique suscipit aliquid? Exercitationem.
                                                    <br /><br>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta odit, aut placeat unde ex molestias sed,
                                                    laborum cupiditate est facilis autem voluptas fuga,
                                                </p>
                                                <div class="d-flex">
                                                    <div>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star-outline pd-star-outline"></i> 
                                                    </div>
                                                    <div class="ml-auto">
                                                        <a href="">
                                                            <span class="badge badge-pill badge-primary">Attach File </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="border-all">
                                                    <label><b>Name:</b></label> <span>Snehal Chavan</span> <br />
                                                    <label><b>Company:</b></label> <span>Google</span> <br />
                                                    <label><b>Date:</b></label> <span>10-12-2018</span> <br />
                                                    <label><b>Contact No:</b></label> <span>0123456789</span> <br />
                                                    <label><b>Mail Id:</b></label> <span>snehal@alliedanalytics.com</span> <br />
                                                    <label><b>Job Designation:</b></label> <span>Graphics Designer</span> <br />
                                                    <label><b>Country:</b></label> <span>India</span>
                                                </div>        
                                            </div>
                                        </div>

                                        <div class="clearfix w-100">&nbsp;</div>
                                        <div class="border-top">&nbsp;</div>
                                        <div class="clearfix w-100"></div>
                                        
                                        <div class="row">
                                            <div class="col-md-8">
                                                <h4 class="pd-tabcontent-title">QUATION : What happens during the primary immune response?</h4>
                                                <p class="pd-tabcontent-desc">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta odit, aut placeat unde ex molestias sed,
                                                    laborum cupiditate est facilis autem voluptas fuga, vel quibusdam quo similique suscipit aliquid?
                                                    Exercitationem.oluta odit, aut placeat unde ex molestias sed, laborum cupiditate est 
                                                    facilis autem voluptas fuga, vel quibusdam quo similique suscipit aliquid? Exercitationem.
                                                    <br /><br>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta odit, aut placeat unde ex molestias sed,
                                                    laborum cupiditate est facilis autem voluptas fuga,
                                                </p>
                                                <div class="d-flex">
                                                    <div>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star-outline pd-star-outline"></i> 
                                                    </div>
                                                    <div class="ml-auto">
                                                        <a href="">
                                                            <span class="badge badge-pill badge-primary">Attach File </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="border-all">
                                                    <label><b>Name:</b></label> <span>Snehal Chavan</span> <br />
                                                    <label><b>Company:</b></label> <span>Google</span> <br />
                                                    <label><b>Date:</b></label> <span>10-12-2018</span> <br />
                                                    <label><b>Contact No:</b></label> <span>0123456789</span> <br />
                                                    <label><b>Mail Id:</b></label> <span>snehal@alliedanalytics.com</span> <br />
                                                    <label><b>Job Designation:</b></label> <span>Graphics Designer</span> <br />
                                                    <label><b>Country:</b></label> <span>India</span>
                                                </div>        
                                            </div>
                                        </div>

                                        <div class="clearfix w-100">&nbsp;</div>
                                        <div class="border-top">&nbsp;</div>
                                        <div class="clearfix w-100"></div>

                                        <div class="row">
                                            <div class="col-md-8">
                                                <h4 class="pd-tabcontent-title">QUATION : What happens during the primary immune response?</h4>
                                                <p class="pd-tabcontent-desc">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta odit, aut placeat unde ex molestias sed,
                                                    laborum cupiditate est facilis autem voluptas fuga, vel quibusdam quo similique suscipit aliquid?
                                                    Exercitationem.oluta odit, aut placeat unde ex molestias sed, laborum cupiditate est 
                                                    facilis autem voluptas fuga, vel quibusdam quo similique suscipit aliquid? Exercitationem.
                                                    <br /><br>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta odit, aut placeat unde ex molestias sed,
                                                    laborum cupiditate est facilis autem voluptas fuga,
                                                </p>
                                                <div class="d-flex">
                                                    <div>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star-outline pd-star-outline"></i> 
                                                    </div>
                                                    <div class="ml-auto">
                                                        <a href="">
                                                            <span class="badge badge-pill badge-primary">Attach File </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="border-all">
                                                    <label><b>Name:</b></label> <span>Snehal Chavan</span> <br />
                                                    <label><b>Company:</b></label> <span>Google</span> <br />
                                                    <label><b>Date:</b></label> <span>10-12-2018</span> <br />
                                                    <label><b>Contact No:</b></label> <span>0123456789</span> <br />
                                                    <label><b>Mail Id:</b></label> <span>snehal@alliedanalytics.com</span> <br />
                                                    <label><b>Job Designation:</b></label> <span>Graphics Designer</span> <br />
                                                    <label><b>Country:</b></label> <span>India</span>
                                                </div>        
                                            </div>
                                        </div>

                                        <div class="clearfix w-100">&nbsp;</div>
                                        <div class="border-top">&nbsp;</div>
                                        <div class="clearfix w-100"></div>

                                        <div class="row">
                                            <div class="col-md-8">
                                                <h4 class="pd-tabcontent-title">QUATION : What happens during the primary immune response?</h4>
                                                <p class="pd-tabcontent-desc">
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta odit, aut placeat unde ex molestias sed,
                                                    laborum cupiditate est facilis autem voluptas fuga, vel quibusdam quo similique suscipit aliquid?
                                                    Exercitationem.oluta odit, aut placeat unde ex molestias sed, laborum cupiditate est 
                                                    facilis autem voluptas fuga, vel quibusdam quo similique suscipit aliquid? Exercitationem.
                                                    <br /><br>
                                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta odit, aut placeat unde ex molestias sed,
                                                    laborum cupiditate est facilis autem voluptas fuga,
                                                </p>
                                                <div class="d-flex">
                                                    <div>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star pd-star-fill"></i>
                                                        <i class="mdi mdi-star-outline pd-star-outline"></i> 
                                                    </div>
                                                    <div class="ml-auto">
                                                        <a href="">
                                                            <span class="badge badge-pill badge-primary">Attach File </span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="border-all">
                                                    <label><b>Name:</b></label> <span>Snehal Chavan</span> <br />
                                                    <label><b>Company:</b></label> <span>Google</span> <br />
                                                    <label><b>Date:</b></label> <span>10-12-2018</span> <br />
                                                    <label><b>Contact No:</b></label> <span>0123456789</span> <br />
                                                    <label><b>Mail Id:</b></label> <span>snehal@alliedanalytics.com</span> <br />
                                                    <label><b>Job Designation:</b></label> <span>Graphics Designer</span> <br />
                                                    <label><b>Country:</b></label> <span>India</span>
                                                </div>        
                                            </div>
                                        </div>
                                        
                                        <div class="clearfix w-100">&nbsp;</div>
                                        <div class="border-top">&nbsp;</div>
                                        <div class="clearfix w-100"></div>

                                        <div class="float-right">
                                            <a href="" class="btn btn-info">EDIT</a> &nbsp;&nbsp;
                                            <a href="" class="btn btn-success">FINISH</a>
                                        </div> 
                                        
                                        <div class="clearfix w-100">&nbsp;</div>   
                                    </div>
                                </div>
                                <?php foreach($questions as $question): ?>
                                    <div class="tab-pane  p-20" id="pri-<?php echo $question->id;?>" role="tabpanel">
                                        <div class="p-20">
                                            <h3 class="mt-2 text-primary"><?php echo $question->question;?></h3>
                                        </div>
                                    </div>
                                <?php endforeach ?>
                                <div class="tab-pane  p-20" id="pri-02" role="tabpanel">
                                    <div class="p-20">
                                        <img src="../../assets/images/background/img4.jpg" class="img-fluid">
                                        <p class="m-t-10">And is full of waffle to It has multiple paragraphs and is full of waffle to pad out the comment. Usually, you just wish these sorts of comments would come to an end.multiple paragraphs and is full of waffle to pad out the comment..</p>
                                    </div>
                                </div>
                                <div class="tab-pane p-20" id="pri-03" role="tabpanel">
                                    <div class="p-20">
                                        <p>And is full of waffle to It has multiple paragraphs and is full of waffle to pad out the comment. Usually, you just wish these sorts of comments would come to an end.multiple paragraphs and is full of waffle to pad out the comment..</p>
                                        <img src="../../assets/images/background/img4.jpg" class="img-fluid">
                                    </div>
                                </div>
                                <div class="tab-pane p-20" id="pri-04" role="tabpanel">
                                    <div class="p-20">
                                        <p>And is full of waffle to It has multiple paragraphs and is full of waffle to pad out the comment. Usually, you just wish these sorts of comments would come to an end.multiple paragraphs and is full of waffle to pad out the comment..</p>
                                        <img src="../../assets/images/background/img4.jpg" class="img-fluid">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer text-center">
                All Rights Reserved by Primary Calling
            </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?= base_url('assets/libs/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?= base_url('assets/libs/popper.js/dist/umd/popper.min.js'); ?>"></script>
    <script src="<?= base_url('assets/libs/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?= base_url('assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js'); ?>"></script>
    <!--Wave Effects -->
    <script src="<?= base_url('assets/js/waves.js'); ?>"></script>
    <!--Menu sidebar -->
    <script src="<?= base_url('assets/js/sidebarmenu.js'); ?>"></script>
    <!--Custom JavaScript -->
    <script src="<?= base_url('assets/js/custom.min.js'); ?>"></script>
</body>

</html>