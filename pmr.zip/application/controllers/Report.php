<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class Report extends CI_Controller{
   
   public function index()
   {
      $this->load->helper('form');
      $this->load->model('Reports');
      $this->load->helper('date');
      $data['cats'] = $this->Reports->getCategories();
      $data['managers'] = $this->Reports->getManagers();
        $time = now('Asia/Kolkata');
        $datestring = '%d/%m/%Y';
        $datestring1 = '%h:%i %a';
        $data['date'] = mdate($datestring, $time);
        $data['time'] = mdate($datestring1, $time);
      $this->load->view('pmr_call/create-new-report',$data);
   }

   public function getSubCats()
   {
      $query = $this->input->post('id');
      $this->load->model('Reports');
      $data = $this->Reports->getSubCategories($query);
      echo json_encode( $data);
   }

   public function saveReport(){

     $title = $this->input->post('title');
     $category = $this->input->post('category');
     $subcategory = $this->input->post('subcategory');
     $manager = $this->input->post('manager');
     $owner_id = $this->input->post('owner_id');
     $questions = $this->input->post('questions');
     $no_of_respondent = $this->input->post('no_of_respondent');
     
     $no_of_questions = count($questions);
    
     $data = array(
              'title' =>$title,
              'category_id' =>$category,
              'subcategory_id' =>$subcategory,
              'manager_id' =>$manager,
              'owner_id' =>$owner_id,
              'no_of_questions' =>$no_of_questions,
              'no_of_respondent' =>$no_of_respondent,
              'created_at' => date('Y-m-d H:i:s')
        );

      $this->load->model('Reports');
      $last_id = $this->Reports->createReport($data);

      foreach($questions as $question){
          $question = array(
              'report_id' => $last_id,
              'question' => $question,
              'created_at' => date('Y-m-d H:i:s')
            );
          $this->Reports->saveQuestions($question);
          
      }
      $data['reports'] = $this->Reports->getPrimaryList();
      // print_r($reports);
      $this->load->view('pmr_call/primary-list',$data);
   }

   public function primaryListing(){
      $this->load->model('Reports');
      $data['reports'] = $this->Reports->getPrimaryList();
      // print_r($reports);
      $this->load->view('pmr_call/primary-list',$data);
   }

   public function view($id){

    $this->load->model('Reports');
    $data['report'] = $this->Reports->showReport($id);
    $data['questions'] = $this->Reports->getQuestions($id);
    // print_r($data);

    $this->load->view('pmr_call/primary-details',$data);

   }

}